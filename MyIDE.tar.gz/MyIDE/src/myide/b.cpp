#include<iostream>

using namespace std;

int main(){
   cout << "hey this is one" << "\n";
 cout << "plz forgive" << "\n";
  return 0;

}
