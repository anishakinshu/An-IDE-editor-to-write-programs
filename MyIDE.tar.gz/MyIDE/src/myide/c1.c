#include<stdio.h>
int main() {
   printf("welldone\n");
   return 0;
}