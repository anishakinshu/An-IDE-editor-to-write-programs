#include<stdio.h>

int main()
{
	printf("HII\n") ;
	return 0 ;
}



















