class A
{
public static void main(String args[])
{
System.out.println("hii");
System.out.println("bye");
}
}
