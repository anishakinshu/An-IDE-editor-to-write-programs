import java.util.*;
class B{
   public static void main(String args[]){
         System.out.println("hey this is my first program");
         Scanner sc = new Scanner(System.in);
        String s = sc.next();
        System.out.println(s); 
   }
}
