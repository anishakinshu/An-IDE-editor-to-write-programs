#include<stdio.h>

int main(){
   int i, j;

  printf("hey this is my first project\n");
  return 0;

}